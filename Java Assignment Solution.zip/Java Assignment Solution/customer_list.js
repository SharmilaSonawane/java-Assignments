$(document).ready(function () {
    // Get the bearer token from localStorage
    const bearerToken = localStorage.getItem('bearerToken');

    // Make a GET request to get the customer list
    $.ajax({
        type: 'GET',
        url: 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list',
        headers: {
            'Authorization': 'Bearer ' + bearerToken
        },
        success: function (data) {
            // Display the customer list in a table
            const customerTable = $('#customerTable');
            customerTable.empty();
            customerTable.append('<tr><th>First Name</th><th>Last Name</th><th>Address</th><th>City</th><th>State</th><th>Email</th><th>Phone</th><th>Action</th></tr>');
            data.forEach(function (customer) {
                customerTable.append('<tr><td>' + customer.first_name + '</td><td>' + customer.last_name + '</td><td>' + customer.street + '</td><td>' + customer.city + '</td><td>' + customer.state + '</td><td>' + customer.email + '</td><td>' + customer.phone + '</td><td><button onclick="deleteCustomer(\'' + customer.uuid + '\')">Delete</button><button onclick="editCustomer(\'' + customer.uuid + '\')">Edit</button></td></tr>');
            });
        },
        error: function (xhr) {
            // Handle the error
            console.log(xhr.responseText);
        }
    });

    // Function to delete a customer
    function deleteCustomer(uuid) {
        // Make a POST request to delete the customer
        $.ajax({
            type: 'POST',
            url: 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp',
            headers: {
                'Authorization': 'Bearer ' + bearerToken
            },
            data: {
                cmd: 'delete',
                uuid: uuid
            },
            success: function (data) {
                // Reload the customer list after successful deletion
                window.location.reload();
            },
            error: function (xhr) {
                // Handle the error
                console.log(xhr.responseText);
            }
        });
    }

    // Function to edit a customer
    function editCustomer(uuid) {
        // Redirect to the edit customer page with the customer UUID as a parameter
        window.location.href = 'edit_customer.html?uuid=' + uuid;
    }
});
