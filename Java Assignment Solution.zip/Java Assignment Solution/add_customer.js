$(document).ready(function () {
    $('#addCustomerForm').on('submit', function (e) {
        e.preventDefault();
        const firstName = $('#first_name').val();
        const lastName = $('#last_name').val();
        const street = $('#street').val();
        const address = $('#address').val();
        const city = $('#city').val();
        const state = $('#state').val();
        const email = $('#email').val();
        const phone = $('#phone').val();

        // Get the bearer token from localStorage
        const bearerToken = localStorage.getItem('bearerToken');

        // Make a POST request to create a new customer
        $.ajax({
            type: 'POST',
            url: 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp',
            headers: {
                'Authorization': 'Bearer ' + bearerToken
            },
            data: JSON.stringify({
                cmd: 'create',
                first_name: firstName,
                last_name: lastName,
                street: street,
                address: address,
                city: city,
                state: state,
                email: email,
                phone: phone
            }),
            contentType: 'application/json',
            success: function (data) {
                // Redirect to the customer list page after successful creation
                window.location.href = 'customer_list.html';
            },
            error: function (xhr) {
                // Handle the error
                console.log(xhr.responseText);
            }
        });
    });
});
