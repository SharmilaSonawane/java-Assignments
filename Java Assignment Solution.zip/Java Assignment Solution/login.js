$(document).ready(function () {
    $('#loginForm').on('submit', function (e) {
        e.preventDefault();
        const username = $('#username').val();
        const password = $('#password').val();

        // Make a POST request to the authentication API with the test credentials
        $.ajax({
            type: 'POST',
            url: 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp',
            data: JSON.stringify({
                login_id: 'test@sunbasedata.com', // Use the provided test username
                password: 'Test@123' // Use the provided test password
            }),
            contentType: 'application/json',
            success: function (data) {
                // Save the bearer token in localStorage for further API calls
                localStorage.setItem('bearerToken', data.access_token);

                // Show the login successful message
                $('#loginMessage').text('Login Successful! Redirecting to Customer List...');

                // Redirect to the customer list page after a delay of 2 seconds
                setTimeout(function () {
                    window.location.href = 'customer_list.html';
                }, 2000); // 2000 milliseconds = 2 seconds
            },
            error: function (xhr) {
                // Display an error message
                $('#loginMessage').text('Login failed. Please check your credentials.');
            }
        });
    });
});
